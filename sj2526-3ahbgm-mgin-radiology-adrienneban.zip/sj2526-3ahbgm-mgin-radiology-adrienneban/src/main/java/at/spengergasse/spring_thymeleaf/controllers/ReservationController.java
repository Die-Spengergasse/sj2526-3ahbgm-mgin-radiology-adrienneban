package at.spengergasse.spring_thymeleaf.controllers;

import at.spengergasse.spring_thymeleaf.entities.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
@RequestMapping("/reservation")
public class ReservationController {

    private final ReservationRepository resRepo;
    private final PatientRepository patientRepository;
    private final DeviceRepository deviceRepository;

    public ReservationController(ReservationRepository resRepo,
                                 PatientRepository patientRepository,
                                 DeviceRepository deviceRepository) {
        this.resRepo = resRepo;
        this.patientRepository = patientRepository;
        this.deviceRepository = deviceRepository;
    }

    @RequestMapping("/list")
    public String reservations(Model model) {
        model.addAttribute("reservations", resRepo.findAll());
        return "reslist";
    }

    @RequestMapping("/add")
    public String addReservation(Model model) {
        model.addAttribute("reservation", new Reservation());
        model.addAttribute("patients", patientRepository.findAll());
        model.addAttribute("devices", deviceRepository.findAll());
        return "add_reservation";
    }

//    @PostMapping("/add")
//    public String addReservation(@ModelAttribute("reservation") Reservation reservation) {
//        resRepo.save(reservation);
//        return "redirect:/reservation/list";
//    }

    @PostMapping("/add")
    public String addReservation(@ModelAttribute Reservation reservation) {
        resRepo.save(reservation);
        return "redirect:/reservation/list";
    }

    @PostMapping("/delete/{id}")
    public String deleteReservation(@PathVariable int id) {
        resRepo.deleteById(id);
        return "redirect:/reservation/list";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable int id, Model model) {
        Reservation reservation = resRepo.findById(id).orElseThrow(null);
        model.addAttribute("reservation", reservation);
        model.addAttribute("patients", patientRepository.findAll());
        model.addAttribute("devices", deviceRepository.findAll());
        return "edit_reservation";
    }

    @RequestMapping("/edit/{id}")
    public String updateReservation(@PathVariable int id, @ModelAttribute Reservation reservation) {
        reservation.setId(id);
        resRepo.save(reservation);
        return "redirect:/reservation/list";
    }

}
