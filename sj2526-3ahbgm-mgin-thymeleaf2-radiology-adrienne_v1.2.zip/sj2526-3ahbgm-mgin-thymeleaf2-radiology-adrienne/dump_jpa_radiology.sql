create or replace table d_devices
(
    d_id       int auto_increment
        primary key,
    d_type     varchar(255) null,
    d_location varchar(255) null
);

create or replace table p_patient
(
    p_id      int auto_increment
        primary key,
    p_name    varchar(255) null,
    p_birth   date         null,
    p_ssn     int(10)      null,
    p_surname varchar(255) null,
    p_gender  char         null,
    birth     date         null,
    gender    varchar(1)   not null,
    name      varchar(255) null,
    ssn       bigint       not null,
    surname   varchar(255) null
);

create or replace table p_patients
(
    id      int auto_increment
        primary key,
    birth   date         null,
    gender  varchar(1)   not null,
    name    varchar(255) null,
    ssn     bigint       not null,
    surname varchar(255) null
);

create or replace table r_reservation
(
    r_id         int auto_increment
        primary key,
    r_startTime  datetime     null,
    r_endTime    datetime     null,
    r_bodyRegion varchar(255) null,
    r_comment    varchar(255) null,
    r_p_id       int          null,
    r_d_id       int          null,
    constraint r_d_fk
        foreign key (r_d_id) references d_devices (d_id),
    constraint r_p_fk
        foreign key (r_p_id) references p_patient (p_id)
);

create or replace table r_reservations
(
    id          int auto_increment
        primary key,
    body_region varchar(255) null,
    comment     varchar(255) null,
    end_time    datetime(6)  null,
    start_time  datetime(6)  null,
    r_d_id      int          null,
    r_p_id      int          null,
    constraint FK41xevwoknbeyy16824t0iltlc
        foreign key (r_p_id) references p_patients (id),
    constraint FK3ipr8u4tso4exs9ox6ej0dfgm
        foreign key (r_p_id) references p_patient (p_id),
    constraint FKalfc7ka3lk817hc44txqe8i38
        foreign key (r_d_id) references d_devices (d_id)
);

create or replace table reservation
(
    id          int auto_increment
        primary key,
    body_region varchar(255) null,
    comment     varchar(255) null,
    end_time    datetime(6)  null,
    start_time  datetime(6)  null,
    r_d_id      int          null,
    r_p_id      int          null,
    constraint FKhx8gip6s8x0tw7xkntgaqcwd2
        foreign key (r_p_id) references p_patients (id)
);


